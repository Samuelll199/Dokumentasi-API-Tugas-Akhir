<?php

namespace Database\Seeders;

use App\Models\Komik;
use Illuminate\Database\Seeder;

class KomikSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = \Faker\Factory::create('id_ID');
        for ($i = 0; $i < 10; $i++){
            Komik::create([
                'judul' => $faker->sentence,
                'pengarang' => $faker->name,
                'tahun_terbit' => $faker->year
            ]);

        }
    }
}
