<?php

namespace Database\Seeders;

use App\Models\Film;
use Illuminate\Database\Seeder;

class FilmSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = \Faker\Factory::create('id_ID');
        for ($i = 0; $i < 10; $i++){
            Film::create([
                'judul' => $faker->sentence,
                'sutradara' => $faker->name,
                'tahun_rilis' => $faker->year
            ]);

        }
    }
}
