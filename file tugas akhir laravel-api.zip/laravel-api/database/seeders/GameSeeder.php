<?php

namespace Database\Seeders;

use App\Models\Game;
use Illuminate\Database\Seeder;

class GameSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = \Faker\Factory::create('id_ID');
        for ($i = 0; $i < 10; $i++){
            Game::create([
                'nama_game' => $faker->sentence,
                'pengembang' => $faker->name,
                'tahun_rilis' => $faker->year
            ]);

        }
    }
}
