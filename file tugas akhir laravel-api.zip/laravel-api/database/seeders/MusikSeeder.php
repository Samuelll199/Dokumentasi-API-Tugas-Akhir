<?php

namespace Database\Seeders;

use App\Models\Musik;
use Illuminate\Database\Seeder;

class MusikSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = \Faker\Factory::create('id_ID');
        for ($i = 0; $i < 10; $i++){
            Musik::create([
                'judul' => $faker->sentence,
                'penyanyi' => $faker->name,
                'tahun_rilis' => $faker->year
            ]);

        }
    }
}
