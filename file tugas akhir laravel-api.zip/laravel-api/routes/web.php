<?php

use App\Http\Controllers\BukuController;
use App\Http\Controllers\FilmController;
use App\Http\Controllers\GameController;
use App\Http\Controllers\KomikController;
use App\Http\Controllers\MusikController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//buku
Route::get('buku',[BukuController::class,'index']);
Route::post('buku',[BukuController::class,'store']);
Route::get('buku/{id}',[BukuController::class,'edit']);
Route::put('buku/{id}',[BukuController::class,'update']);
Route::delete('buku/{id}',[BukuController::class,'destroy']);

//film
Route::get('film',[FilmController::class,'index']);
Route::post('film',[FilmController::class,'store']);
Route::get('film/{id}',[FilmController::class,'edit']);
Route::put('film/{id}',[FilmController::class,'update']);
Route::delete('film/{id}',[FilmController::class,'destroy']);

//game
Route::get('game',[GameController::class,'index']);
Route::post('game',[GameController::class,'store']);
Route::get('game/{id}',[GameController::class,'edit']);
Route::put('game/{id}',[GameController::class,'update']);
Route::delete('game/{id}',[GameController::class,'destroy']);

//musik
Route::get('musik',[MusikController::class,'index']);
Route::post('musik',[MusikController::class,'store']);
Route::get('musik/{id}',[MusikController::class,'edit']);
Route::put('musik/{id}',[MusikController::class,'update']);
Route::delete('musik/{id}',[MusikController::class,'destroy']);

//komik
Route::get('komik',[KomikController::class,'index']);
Route::post('komik',[KomikController::class,'store']);
Route::get('komik/{id}',[KomikController::class,'edit']);
Route::put('komik/{id}',[KomikController::class,'update']);
Route::delete('komik/{id}',[KomikController::class,'destroy']);