<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Musik;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class MusikController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Musik::orderBy('judul','asc')->get();
        return response()->json([
            'status'=>true,
            'message'=>'Data ditemukan',
            'data'=>$data
        ],200);  
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $dataMusik = new Musik;

        $rules = [
            'judul' => 'required',
            'penyanyi' => 'required',
            'tahun_rilis' => 'required'
        ];
        $validator = Validator::make($request->all(),$rules);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Gagal Menambahkan Data',
                'data' => $validator->errors()
            ]);
        }


        $dataMusik->judul = $request->judul;
        $dataMusik->penyanyi = $request->penyanyi;
        $dataMusik->tahun_rilis = $request->tahun_rilis;

        $post = $dataMusik->save();
        
        return response()->json([
            'status' => true,
            'message' => 'Sukses Menambahkan data'
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Musik::find($id);
        if($data){
            return response()->json([
                'status' => true,
                'message' => 'Data ditemukan',
                'data' => $data
            ],200);
        }else{
            return response()->json([
                'status' => false,
                'message' => 'Data tidak ditemukan'
            ]);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $dataMusik = Musik::find($id);
        if(empty($dataMusik)){
            return response()->json([
            'status'=> false,
            'message'=>'Data Tidak ditemukan'
            ], 404);
        }

        $rules = [
            'judul' => 'required',
            'penyanyi' => 'required',
            'tahun_rilis' => 'required'
        ];
        $validator = Validator::make($request->all(),$rules);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Gagal Melakukan update Data',
                'data' => $validator->errors()
            ]);
        }


        $dataMusik->judul = $request->judul;
        $dataMusik->penyanyi = $request->penyanyi;
        $dataMusik->tahun_rilis = $request->tahun_rilis;

        $post = $dataMusik->save();
        
        return response()->json([
            'status' => true,
            'message' => 'Sukses Melakukan update data'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $dataMusik = Musik::find($id);
        if(empty($dataMusik)){
            return response()->json([
            'status'=> false,
            'message'=>'Data Tidak ditemukan'
            ], 404);
        }

        

        $post = $dataMusik->delete();
        
        return response()->json([
            'status' => true,
            'message' => 'Sukses Melakukan delete data'
        ]);
    }
}
