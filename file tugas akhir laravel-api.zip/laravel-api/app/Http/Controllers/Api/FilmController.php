<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Film;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class FilmController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Film::orderBy('judul','asc')->get();
        return response()->json([
            'status'=>true,
            'message'=>'Data ditemukan',
            'data'=>$data
        ],200);  
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $dataFilm = new Film;

        $rules = [
            'judul' => 'required',
            'sutradara' => 'required',
            'tahun_rilis' => 'required'
        ];
        $validator = Validator::make($request->all(),$rules);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Gagal Menambahkan Data',
                'data' => $validator->errors()
            ]);
        }


        $dataFilm->judul = $request->judul;
        $dataFilm->sutradara = $request->sutradara;
        $dataFilm->tahun_rilis = $request->tahun_rilis;

        $post = $dataFilm->save();
        
        return response()->json([
            'status' => true,
            'message' => 'Sukses Menambahkan data'
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Film::find($id);
        if($data){
            return response()->json([
                'status' => true,
                'message' => 'Data ditemukan',
                'data' => $data
            ],200);
        }else{
            return response()->json([
                'status' => false,
                'message' => 'Data tidak ditemukan'
            ]);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $dataFilm = Film::find($id);
        if(empty($dataFilm)){
            return response()->json([
            'status'=> false,
            'message'=>'Data Tidak ditemukan'
            ], 404);
        }

        $rules = [
            'judul' => 'required',
            'sutradara' => 'required',
            'tahun_rilis' => 'required'
        ];
        $validator = Validator::make($request->all(),$rules);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Gagal Melakukan update Data',
                'data' => $validator->errors()
            ]);
        }


        $dataFilm->judul = $request->judul;
        $dataFilm->sutradara = $request->sutradara;
        $dataFilm->tahun_rilis = $request->tahun_rilis;

        $post = $dataFilm->save();
        
        return response()->json([
            'status' => true,
            'message' => 'Sukses Melakukan update data'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $dataFilm = Film::find($id);
        if(empty($dataFilm)){
            return response()->json([
            'status'=> false,
            'message'=>'Data Tidak ditemukan'
            ], 404);
        }

        

        $post = $dataFilm->delete();
        
        return response()->json([
            'status' => true,
            'message' => 'Sukses Melakukan delete data'
        ]);
    }
}
